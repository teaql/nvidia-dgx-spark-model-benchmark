#![allow(unused_imports)]
#![allow(async_fn_in_trait)]
use std::{collections::BTreeMap, future::Future, marker::PhantomData};

use serde_json::Value as JsonValue;
use teaql_core::{
    BinaryOp, Expr, Record,
    RelationAggregate as RuntimeRelationAggregate, SelectQuery, SmartList,
};
use teaql_runtime::{ContextError, GraphNode, EntityDataServiceBehavior, DataServiceError, RuntimeError, UserContext};

// Re-export query builder types from teaql_core::request
pub use teaql_core::request::{
    COUNT_ALIAS, TYPE_FIELD, TYPE_GROUP_FIELD,
    FieldOperator, DateRange, EntityReference,
    QuerySelection, RelationSelection, RelationFilter, QueryOptions,
    UnsafeRawSqlSegment, RawDynamicProperty, RawProjection,
    RelationAggregate, FacetRequest, ObjectGroupBy,
    apply_relation_selections, apply_runtime_metadata,
    field_operator_expr, field_operator_column_expr,
    required_value, required_text,
    remove_default_live_filter, remove_filter_expr,
    dynamic_json_value_to_teaql_value, dynamic_json_values,
    dynamic_json_operator, dynamic_json_filter_expr,
    dynamic_json_u64_field,
    runtime_relation_aggregates,
    merge_outer_filter_into_facet_aggregates, attach_facets,
};


pub trait TeaqlRecordRepository {
    type Error: std::error::Error + Send + Sync + 'static;

    async fn fetch_all(&self, query: &SelectQuery) -> Result<Vec<Record>, DataServiceError<Self::Error>>;

    async fn fetch_smart_list(&self, query: &SelectQuery) -> Result<SmartList<Record>, DataServiceError<Self::Error>>;

    async fn fetch_smart_list_with_relation_aggregates(
        &self,
        query: &SelectQuery,
        relation_aggregates: &[RuntimeRelationAggregate],
    ) -> Result<SmartList<Record>, DataServiceError<Self::Error>>;

    async fn fetch_stream(&self, query: &SelectQuery) -> Result<Vec<teaql_data_service::StreamChunk>, DataServiceError<Self::Error>>;
}

pub trait TeaqlEntityRepository: TeaqlRecordRepository {
    async fn fetch_enhanced_entities<T>(&self, query: &SelectQuery) -> Result<SmartList<T>, DataServiceError<Self::Error>>
    where
        T: teaql_core::Entity;

    async fn fetch_enhanced_entities_with_relation_aggregates<T>(
        &self,
        query: &SelectQuery,
        relation_aggregates: &[RuntimeRelationAggregate],
    ) -> Result<SmartList<T>, DataServiceError<Self::Error>>
    where
        T: teaql_core::Entity;

    async fn save_entity_graph<T>(&self, entity: T) -> Result<GraphNode, DataServiceError<Self::Error>>
    where
        T: teaql_core::Entity;

    async fn save_entity_ledger(&self, root: teaql_runtime::EntityRoot) -> Result<(), DataServiceError<Self::Error>>;
}

impl<'a, E> TeaqlRecordRepository for teaql_runtime::EntityDataService<'a, E>
where
    E: teaql_data_service::QueryExecutor + teaql_data_service::MutationExecutor + teaql_data_service::StreamQueryExecutor + Send + Sync + 'static,
{
    type Error = E::Error;

    async fn fetch_all(&self, query: &SelectQuery) -> Result<Vec<Record>, DataServiceError<Self::Error>> {
        teaql_runtime::EntityDataService::fetch_all(self, query).await
    }

    async fn fetch_smart_list(&self, query: &SelectQuery) -> Result<SmartList<Record>, DataServiceError<Self::Error>> {
        teaql_runtime::EntityDataService::fetch_smart_list(self, query).await
    }

    async fn fetch_smart_list_with_relation_aggregates(
        &self,
        query: &SelectQuery,
        relation_aggregates: &[RuntimeRelationAggregate],
    ) -> Result<SmartList<Record>, DataServiceError<Self::Error>> {
        teaql_runtime::EntityDataService::fetch_smart_list_with_relation_aggregates(
            self,
            query,
            relation_aggregates,
        ).await
    }

    async fn fetch_stream(&self, query: &SelectQuery) -> Result<Vec<teaql_data_service::StreamChunk>, DataServiceError<Self::Error>> {
        teaql_runtime::EntityDataService::fetch_stream(self, query).await
    }
}

impl<'a, E> TeaqlEntityRepository for teaql_runtime::EntityDataService<'a, E>
where
    E: teaql_data_service::QueryExecutor + teaql_data_service::MutationExecutor + teaql_data_service::StreamQueryExecutor + Send + Sync + 'static,
{
    async fn fetch_enhanced_entities<T>(&self, query: &SelectQuery) -> Result<SmartList<T>, DataServiceError<Self::Error>>
    where
        T: teaql_core::Entity,
    {
        teaql_runtime::EntityDataService::fetch_enhanced_entities(self, query).await
    }

    async fn fetch_enhanced_entities_with_relation_aggregates<T>(
        &self,
        query: &SelectQuery,
        relation_aggregates: &[RuntimeRelationAggregate],
    ) -> Result<SmartList<T>, DataServiceError<Self::Error>>
    where
        T: teaql_core::Entity,
    {
        teaql_runtime::EntityDataService::fetch_enhanced_entities_with_relation_aggregates(
            self,
            query,
            relation_aggregates,
        ).await
    }

    async fn save_entity_graph<T>(&self, entity: T) -> Result<GraphNode, DataServiceError<Self::Error>>
    where
        T: teaql_core::Entity,
    {
        teaql_runtime::EntityDataService::save_entity_graph(self, entity).await
    }

    async fn save_entity_ledger(&self, root: teaql_runtime::EntityRoot) -> Result<(), DataServiceError<Self::Error>> {
        teaql_runtime::EntityDataService::execute_ledger_plan(self, root).await
    }
}

pub type TeaqlDataServiceError<R> = DataServiceError<<R as TeaqlRecordRepository>::Error>;

pub trait TeaqlRuntime {
    fn user_context(&self) -> &UserContext;

    fn fetch_facet_smart_list(
        &self,
        entity: &str,
        query: &SelectQuery,
        relation_aggregates: &[RuntimeRelationAggregate],
        trace_context: Vec<teaql_core::TraceNode>,
    ) -> impl std::future::Future<Output = Result<SmartList<Record>, RuntimeError>> + Send;
}

/// Internal trait for repository access. Application code should not use this trait directly.
#[doc(hidden)]
pub trait AuditedSave<'a, C>
where
    C: TeaqlRepositoryProvider + ?Sized + 'a,
{
    type Error;
    fn save(self, ctx: &'a C) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<teaql_runtime::GraphNode, Self::Error>> + '_>>;
}



pub trait TeaqlRepositoryProvider: TeaqlRuntime {
    type CustomerRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn customer_repository(&self) -> Result<Self::CustomerRepository<'_>, ContextError>;
    type LeadRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn lead_repository(&self) -> Result<Self::LeadRepository<'_>, ContextError>;
    type QuoteRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn quote_repository(&self) -> Result<Self::QuoteRepository<'_>, ContextError>;
    type ContractRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn contract_repository(&self) -> Result<Self::ContractRepository<'_>, ContextError>;
    type InvoiceRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn invoice_repository(&self) -> Result<Self::InvoiceRepository<'_>, ContextError>;
    type PaymentRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn payment_repository(&self) -> Result<Self::PaymentRepository<'_>, ContextError>;
    type SalesOrderRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn sales_order_repository(&self) -> Result<Self::SalesOrderRepository<'_>, ContextError>;
    type SalesRepRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn sales_rep_repository(&self) -> Result<Self::SalesRepRepository<'_>, ContextError>;
    type TerritoryRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn territory_repository(&self) -> Result<Self::TerritoryRepository<'_>, ContextError>;
    type PricingRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn pricing_repository(&self) -> Result<Self::PricingRepository<'_>, ContextError>;
    type DiscountRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn discount_repository(&self) -> Result<Self::DiscountRepository<'_>, ContextError>;
    type PromotionRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn promotion_repository(&self) -> Result<Self::PromotionRepository<'_>, ContextError>;
    type CampaignRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn campaign_repository(&self) -> Result<Self::CampaignRepository<'_>, ContextError>;
    type FeedbackRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn feedback_repository(&self) -> Result<Self::FeedbackRepository<'_>, ContextError>;
    type ComplaintRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn complaint_repository(&self) -> Result<Self::ComplaintRepository<'_>, ContextError>;
    type ServiceRequestRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn service_request_repository(&self) -> Result<Self::ServiceRequestRepository<'_>, ContextError>;
    type WarrantyRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn warranty_repository(&self) -> Result<Self::WarrantyRepository<'_>, ContextError>;
    type RenewalRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn renewal_repository(&self) -> Result<Self::RenewalRepository<'_>, ContextError>;
    type UpsellRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn upsell_repository(&self) -> Result<Self::UpsellRepository<'_>, ContextError>;
    type CrossSellRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn cross_sell_repository(&self) -> Result<Self::CrossSellRepository<'_>, ContextError>;
    type TruckRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn truck_repository(&self) -> Result<Self::TruckRepository<'_>, ContextError>;
    type TrailerRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn trailer_repository(&self) -> Result<Self::TrailerRepository<'_>, ContextError>;
    type DriverRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn driver_repository(&self) -> Result<Self::DriverRepository<'_>, ContextError>;
    type MoveOrderRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn move_order_repository(&self) -> Result<Self::MoveOrderRepository<'_>, ContextError>;
    type RouteRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn route_repository(&self) -> Result<Self::RouteRepository<'_>, ContextError>;
    type ScheduleRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn schedule_repository(&self) -> Result<Self::ScheduleRepository<'_>, ContextError>;
    type LoadRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn load_repository(&self) -> Result<Self::LoadRepository<'_>, ContextError>;
    type UnloadRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn unload_repository(&self) -> Result<Self::UnloadRepository<'_>, ContextError>;
    type WarehouseRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn warehouse_repository(&self) -> Result<Self::WarehouseRepository<'_>, ContextError>;
    type InventoryRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn inventory_repository(&self) -> Result<Self::InventoryRepository<'_>, ContextError>;
    type PalletRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn pallet_repository(&self) -> Result<Self::PalletRepository<'_>, ContextError>;
    type ShipmentRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn shipment_repository(&self) -> Result<Self::ShipmentRepository<'_>, ContextError>;
    type TrackingRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn tracking_repository(&self) -> Result<Self::TrackingRepository<'_>, ContextError>;
    type FuelLogRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn fuel_log_repository(&self) -> Result<Self::FuelLogRepository<'_>, ContextError>;
    type MaintenanceRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn maintenance_repository(&self) -> Result<Self::MaintenanceRepository<'_>, ContextError>;
    type InspectionRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn inspection_repository(&self) -> Result<Self::InspectionRepository<'_>, ContextError>;
    type SafetyReportRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn safety_report_repository(&self) -> Result<Self::SafetyReportRepository<'_>, ContextError>;
    type CrewRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn crew_repository(&self) -> Result<Self::CrewRepository<'_>, ContextError>;
    type EquipmentRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn equipment_repository(&self) -> Result<Self::EquipmentRepository<'_>, ContextError>;
    type FacilityRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn facility_repository(&self) -> Result<Self::FacilityRepository<'_>, ContextError>;
    type BudgetRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn budget_repository(&self) -> Result<Self::BudgetRepository<'_>, ContextError>;
    type ExpenseRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn expense_repository(&self) -> Result<Self::ExpenseRepository<'_>, ContextError>;
    type RevenueRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn revenue_repository(&self) -> Result<Self::RevenueRepository<'_>, ContextError>;
    type ProfitRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn profit_repository(&self) -> Result<Self::ProfitRepository<'_>, ContextError>;
    type LossRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn loss_repository(&self) -> Result<Self::LossRepository<'_>, ContextError>;
    type TaxRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn tax_repository(&self) -> Result<Self::TaxRepository<'_>, ContextError>;
    type AuditRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn audit_repository(&self) -> Result<Self::AuditRepository<'_>, ContextError>;
    type LedgerRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn ledger_repository(&self) -> Result<Self::LedgerRepository<'_>, ContextError>;
    type JournalRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn journal_repository(&self) -> Result<Self::JournalRepository<'_>, ContextError>;
    type AccountsPayableRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn accounts_payable_repository(&self) -> Result<Self::AccountsPayableRepository<'_>, ContextError>;
    type AccountsReceivableRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn accounts_receivable_repository(&self) -> Result<Self::AccountsReceivableRepository<'_>, ContextError>;
    type PayrollRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn payroll_repository(&self) -> Result<Self::PayrollRepository<'_>, ContextError>;
    type ExpenseReportRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn expense_report_repository(&self) -> Result<Self::ExpenseReportRepository<'_>, ContextError>;
    type BudgetForecastRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn budget_forecast_repository(&self) -> Result<Self::BudgetForecastRepository<'_>, ContextError>;
    type CashFlowRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn cash_flow_repository(&self) -> Result<Self::CashFlowRepository<'_>, ContextError>;
    type InvestmentRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn investment_repository(&self) -> Result<Self::InvestmentRepository<'_>, ContextError>;
    type AssetRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn asset_repository(&self) -> Result<Self::AssetRepository<'_>, ContextError>;
    type LiabilityRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn liability_repository(&self) -> Result<Self::LiabilityRepository<'_>, ContextError>;
    type EquityRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn equity_repository(&self) -> Result<Self::EquityRepository<'_>, ContextError>;
    type FinancialStatementRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn financial_statement_repository(&self) -> Result<Self::FinancialStatementRepository<'_>, ContextError>;
    type EmployeeRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn employee_repository(&self) -> Result<Self::EmployeeRepository<'_>, ContextError>;
    type ContractorRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn contractor_repository(&self) -> Result<Self::ContractorRepository<'_>, ContextError>;
    type BeneficiaryRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn beneficiary_repository(&self) -> Result<Self::BeneficiaryRepository<'_>, ContextError>;
    type DependentRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn dependent_repository(&self) -> Result<Self::DependentRepository<'_>, ContextError>;
    type TrainingRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn training_repository(&self) -> Result<Self::TrainingRepository<'_>, ContextError>;
    type CertificationRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn certification_repository(&self) -> Result<Self::CertificationRepository<'_>, ContextError>;
    type PerformanceReviewRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn performance_review_repository(&self) -> Result<Self::PerformanceReviewRepository<'_>, ContextError>;
    type TerminationRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn termination_repository(&self) -> Result<Self::TerminationRepository<'_>, ContextError>;
    type OnboardingRepository<'a>: TeaqlEntityRepository + 'a
    where
        Self: 'a;

    fn onboarding_repository(&self) -> Result<Self::OnboardingRepository<'_>, ContextError>;
}

#[allow(async_fn_in_trait)]
pub trait TeaqlUserContextExt {
    async fn commit_data(&self) -> Result<(), DataServiceError<<crate::runtime::DataServiceExecutor as teaql_data_service::DataServiceExecutor>::Error>>;

    async fn transaction_data<F, Fut>(&self, f: F) -> Result<(), DataServiceError<<crate::runtime::DataServiceExecutor as teaql_data_service::DataServiceExecutor>::Error>>
    where
        F: FnOnce() -> Fut,
        Fut: Future<Output = Result<(), DataServiceError<<crate::runtime::DataServiceExecutor as teaql_data_service::DataServiceExecutor>::Error>>>;
}

impl TeaqlUserContextExt for teaql_runtime::UserContext {
    async fn commit_data(&self) -> Result<(), DataServiceError<<crate::runtime::DataServiceExecutor as teaql_data_service::DataServiceExecutor>::Error>> {
        self.commit_changes::<crate::runtime::DataServiceExecutor>().await
    }

    async fn transaction_data<F, Fut>(&self, f: F) -> Result<(), DataServiceError<<crate::runtime::DataServiceExecutor as teaql_data_service::DataServiceExecutor>::Error>>
    where
        F: FnOnce() -> Fut,
        Fut: Future<Output = Result<(), DataServiceError<<crate::runtime::DataServiceExecutor as teaql_data_service::DataServiceExecutor>::Error>>>,
    {
        let executor = self.require_resource::<crate::runtime::DataServiceExecutor>().map_err(|err| {
            DataServiceError::Runtime(RuntimeError::Graph(format!(
                "cannot start transaction without executor: {err}"
            )))
        })?;
        let root = self.entity_root();

        let tx = teaql_data_service::TransactionExecutor::begin(&*executor).await.map_err(DataServiceError::Executor)?;
        root.push_change_set();

        let result = f().await;
        match result {
            Ok(()) => {
                root.pop_change_set();
                teaql_data_service::Transaction::commit(tx).await.map_err(DataServiceError::Executor)?;
                Ok(())
            }
            Err(err) => {
                root.pop_change_set();
                teaql_data_service::Transaction::rollback(tx).await.map_err(DataServiceError::Executor)?;
                Err(err)
            }
        }
    }
}

impl TeaqlRuntime for teaql_runtime::UserContext {
    fn user_context(&self) -> &UserContext {
        self
    }

    async fn fetch_facet_smart_list(
        &self,
        entity: &str,
        query: &SelectQuery,
        relation_aggregates: &[RuntimeRelationAggregate],
        trace_context: Vec<teaql_core::TraceNode>,
    ) -> Result<SmartList<Record>, RuntimeError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>(entity)
            .map_err(|err| RuntimeError::Graph(err.to_string()))?
            .with_trace_context(trace_context)
            .fetch_smart_list_with_relation_aggregates(query, relation_aggregates)
            .await
            .map_err(|err| RuntimeError::Graph(err.to_string()))
    }
}

impl TeaqlRepositoryProvider for teaql_runtime::UserContext {
    type CustomerRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn customer_repository(&self) -> Result<Self::CustomerRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Customer")
    }

    type LeadRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn lead_repository(&self) -> Result<Self::LeadRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Lead")
    }

    type QuoteRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn quote_repository(&self) -> Result<Self::QuoteRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Quote")
    }

    type ContractRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn contract_repository(&self) -> Result<Self::ContractRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Contract")
    }

    type InvoiceRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn invoice_repository(&self) -> Result<Self::InvoiceRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Invoice")
    }

    type PaymentRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn payment_repository(&self) -> Result<Self::PaymentRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Payment")
    }

    type SalesOrderRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn sales_order_repository(&self) -> Result<Self::SalesOrderRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("SalesOrder")
    }

    type SalesRepRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn sales_rep_repository(&self) -> Result<Self::SalesRepRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("SalesRep")
    }

    type TerritoryRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn territory_repository(&self) -> Result<Self::TerritoryRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Territory")
    }

    type PricingRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn pricing_repository(&self) -> Result<Self::PricingRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Pricing")
    }

    type DiscountRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn discount_repository(&self) -> Result<Self::DiscountRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Discount")
    }

    type PromotionRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn promotion_repository(&self) -> Result<Self::PromotionRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Promotion")
    }

    type CampaignRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn campaign_repository(&self) -> Result<Self::CampaignRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Campaign")
    }

    type FeedbackRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn feedback_repository(&self) -> Result<Self::FeedbackRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Feedback")
    }

    type ComplaintRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn complaint_repository(&self) -> Result<Self::ComplaintRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Complaint")
    }

    type ServiceRequestRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn service_request_repository(&self) -> Result<Self::ServiceRequestRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("ServiceRequest")
    }

    type WarrantyRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn warranty_repository(&self) -> Result<Self::WarrantyRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Warranty")
    }

    type RenewalRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn renewal_repository(&self) -> Result<Self::RenewalRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Renewal")
    }

    type UpsellRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn upsell_repository(&self) -> Result<Self::UpsellRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Upsell")
    }

    type CrossSellRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn cross_sell_repository(&self) -> Result<Self::CrossSellRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("CrossSell")
    }

    type TruckRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn truck_repository(&self) -> Result<Self::TruckRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Truck")
    }

    type TrailerRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn trailer_repository(&self) -> Result<Self::TrailerRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Trailer")
    }

    type DriverRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn driver_repository(&self) -> Result<Self::DriverRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Driver")
    }

    type MoveOrderRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn move_order_repository(&self) -> Result<Self::MoveOrderRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("MoveOrder")
    }

    type RouteRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn route_repository(&self) -> Result<Self::RouteRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Route")
    }

    type ScheduleRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn schedule_repository(&self) -> Result<Self::ScheduleRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Schedule")
    }

    type LoadRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn load_repository(&self) -> Result<Self::LoadRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Load")
    }

    type UnloadRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn unload_repository(&self) -> Result<Self::UnloadRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Unload")
    }

    type WarehouseRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn warehouse_repository(&self) -> Result<Self::WarehouseRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Warehouse")
    }

    type InventoryRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn inventory_repository(&self) -> Result<Self::InventoryRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Inventory")
    }

    type PalletRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn pallet_repository(&self) -> Result<Self::PalletRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Pallet")
    }

    type ShipmentRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn shipment_repository(&self) -> Result<Self::ShipmentRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Shipment")
    }

    type TrackingRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn tracking_repository(&self) -> Result<Self::TrackingRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Tracking")
    }

    type FuelLogRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn fuel_log_repository(&self) -> Result<Self::FuelLogRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("FuelLog")
    }

    type MaintenanceRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn maintenance_repository(&self) -> Result<Self::MaintenanceRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Maintenance")
    }

    type InspectionRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn inspection_repository(&self) -> Result<Self::InspectionRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Inspection")
    }

    type SafetyReportRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn safety_report_repository(&self) -> Result<Self::SafetyReportRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("SafetyReport")
    }

    type CrewRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn crew_repository(&self) -> Result<Self::CrewRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Crew")
    }

    type EquipmentRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn equipment_repository(&self) -> Result<Self::EquipmentRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Equipment")
    }

    type FacilityRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn facility_repository(&self) -> Result<Self::FacilityRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Facility")
    }

    type BudgetRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn budget_repository(&self) -> Result<Self::BudgetRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Budget")
    }

    type ExpenseRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn expense_repository(&self) -> Result<Self::ExpenseRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Expense")
    }

    type RevenueRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn revenue_repository(&self) -> Result<Self::RevenueRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Revenue")
    }

    type ProfitRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn profit_repository(&self) -> Result<Self::ProfitRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Profit")
    }

    type LossRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn loss_repository(&self) -> Result<Self::LossRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Loss")
    }

    type TaxRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn tax_repository(&self) -> Result<Self::TaxRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Tax")
    }

    type AuditRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn audit_repository(&self) -> Result<Self::AuditRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Audit")
    }

    type LedgerRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn ledger_repository(&self) -> Result<Self::LedgerRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Ledger")
    }

    type JournalRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn journal_repository(&self) -> Result<Self::JournalRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Journal")
    }

    type AccountsPayableRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn accounts_payable_repository(&self) -> Result<Self::AccountsPayableRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("AccountsPayable")
    }

    type AccountsReceivableRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn accounts_receivable_repository(&self) -> Result<Self::AccountsReceivableRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("AccountsReceivable")
    }

    type PayrollRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn payroll_repository(&self) -> Result<Self::PayrollRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Payroll")
    }

    type ExpenseReportRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn expense_report_repository(&self) -> Result<Self::ExpenseReportRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("ExpenseReport")
    }

    type BudgetForecastRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn budget_forecast_repository(&self) -> Result<Self::BudgetForecastRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("BudgetForecast")
    }

    type CashFlowRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn cash_flow_repository(&self) -> Result<Self::CashFlowRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("CashFlow")
    }

    type InvestmentRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn investment_repository(&self) -> Result<Self::InvestmentRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Investment")
    }

    type AssetRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn asset_repository(&self) -> Result<Self::AssetRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Asset")
    }

    type LiabilityRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn liability_repository(&self) -> Result<Self::LiabilityRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Liability")
    }

    type EquityRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn equity_repository(&self) -> Result<Self::EquityRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Equity")
    }

    type FinancialStatementRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn financial_statement_repository(&self) -> Result<Self::FinancialStatementRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("FinancialStatement")
    }

    type EmployeeRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn employee_repository(&self) -> Result<Self::EmployeeRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Employee")
    }

    type ContractorRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn contractor_repository(&self) -> Result<Self::ContractorRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Contractor")
    }

    type BeneficiaryRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn beneficiary_repository(&self) -> Result<Self::BeneficiaryRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Beneficiary")
    }

    type DependentRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn dependent_repository(&self) -> Result<Self::DependentRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Dependent")
    }

    type TrainingRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn training_repository(&self) -> Result<Self::TrainingRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Training")
    }

    type CertificationRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn certification_repository(&self) -> Result<Self::CertificationRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Certification")
    }

    type PerformanceReviewRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn performance_review_repository(&self) -> Result<Self::PerformanceReviewRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("PerformanceReview")
    }

    type TerminationRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn termination_repository(&self) -> Result<Self::TerminationRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Termination")
    }

    type OnboardingRepository<'a> = teaql_runtime::EntityDataService<'a, crate::runtime::DataServiceExecutor>
    where
        Self: 'a;

    fn onboarding_repository(&self) -> Result<Self::OnboardingRepository<'_>, ContextError> {
        self.entity_data_service::<crate::runtime::DataServiceExecutor>("Onboarding")
    }
}

pub(crate) async fn execute_facets<C>(
    ctx: &C,
    outer_query: &SelectQuery,
    options: &QueryOptions,
) -> Result<BTreeMap<String, SmartList<Record>>, RuntimeError>
where
    C: TeaqlRuntime + ?Sized,
{
    let mut facets = BTreeMap::new();
    for facet in &options.facets {
        let mut selection = facet.query.clone();
        merge_outer_filter_into_facet_aggregates(&mut selection, outer_query);
        if !facet.include_all_facets {
            selection = restrict_facet_to_outer_query(ctx, selection, outer_query, &facet.relation_name)?;
        }
        let relation_aggregates = runtime_relation_aggregates(&selection.query_options);
        let query = apply_runtime_metadata(
            selection.query,
            &selection.query_options,
            &selection.child_enhancements,
        );
        let mut chain = outer_query.trace_chain.clone();
        chain.push(teaql_core::TraceNode::new(
            query.entity.clone(),
            None,
            facet.facet_name.clone(),
        ));

        let facet_rows = ctx.fetch_facet_smart_list(&query.entity, &query, &relation_aggregates, chain).await?;
        facets.insert(facet.facet_name.clone(), facet_rows);
    }
    Ok(facets)
}

pub(crate) fn restrict_facet_to_outer_query<C>(
    ctx: &C,
    mut selection: QuerySelection,
    outer_query: &SelectQuery,
    relation_name: &str,
) -> Result<QuerySelection, RuntimeError>
where
    C: TeaqlRuntime + ?Sized,
{
    let descriptor = ctx
        .user_context()
        .entity(&outer_query.entity)
        .cloned()
        .ok_or_else(|| RuntimeError::Graph(format!("missing entity: {}", outer_query.entity)))?;
    let relation = descriptor
        .relation_by_name(relation_name)
        .cloned()
        .ok_or_else(|| RuntimeError::MissingRelation {
            entity: outer_query.entity.clone(),
            relation: relation_name.to_owned(),
        })?;
    let mut subquery = outer_query.clone();
    subquery.projection.clear();
    subquery.expr_projection.clear();
    subquery.order_by.clear();
    subquery.slice = None;
    subquery.aggregates.clear();
    subquery.group_by.clear();
    subquery.relations.clear();
    selection.query = selection.query.and_filter(Expr::in_subquery(
        relation.foreign_key,
        descriptor,
        subquery,
        relation.local_key,
    ));
    Ok(selection)
}
