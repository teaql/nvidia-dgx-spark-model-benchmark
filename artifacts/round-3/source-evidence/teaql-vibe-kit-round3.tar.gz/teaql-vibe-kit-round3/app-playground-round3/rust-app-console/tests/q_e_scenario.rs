#[tokio::test]
async fn q_and_e_school_scenario_runs_against_sqlite() -> Result<(), Box<dyn std::error::Error>> {
    let database_path = std::env::temp_dir().join(format!(
        "teaql-school-q-e-{}-{}.db",
        std::process::id(),
        chrono::Utc::now().timestamp_nanos_opt().unwrap_or_default()
    ));
    std::env::set_var(
        "SCHOOL_SERVICE_CORE_DATABASE_URL",
        format!("sqlite://{}", database_path.display()),
    );

    let mut runtime = school_service_core::service_runtime_from_env().await?;
    runtime.ensure_schema().await?;
    let result = school_service_core_workspace::run_school_scenario(&mut runtime).await?;

    assert_eq!(result.extracted_school_name, "Sunshine Primary School");
    assert_eq!(
        result.extracted_platform_name,
        "Standard Education Platform"
    );
    assert_eq!(result.extracted_school_type_code, "PRIMARY");
    assert_eq!(result.extracted_school_type_code_via_school, "PRIMARY");
    assert_eq!(result.extracted_platform_id, 1);
    assert_eq!(result.extracted_student_count, 320);
    assert_eq!(result.primary_school_count, 1);
    assert_eq!(result.primary_school_type_count, 1);
    assert!(result.sql_log_count >= 4);

    Ok(())
}
