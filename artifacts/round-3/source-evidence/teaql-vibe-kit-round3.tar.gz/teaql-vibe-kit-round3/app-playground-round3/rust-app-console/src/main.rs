#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!(
        "[{}] Starting application...",
        chrono::Local::now().format("%Y-%m-%d %H:%M:%S%.3f")
    );
    let mut _runtime = school_service_core::service_runtime_from_env().await?;
    _runtime.ensure_schema().await?;

    let result = school_service_core_workspace::run_school_scenario(&mut _runtime).await?;
    println!(
        "Q/E scenario passed: {} Primary school row(s), {} Primary type row(s), \
         E school = {:?}, platform = {:?}, type = {:?}, platform_id = {}, \
         students = {}, {} SQL log entries",
        result.primary_school_count,
        result.primary_school_type_count,
        result.extracted_school_name,
        result.extracted_platform_name,
        result.extracted_school_type_code_via_school,
        result.extracted_platform_id,
        result.extracted_student_count,
        result.sql_log_count
    );

    // Capture and print SQL logs
    let sql_logs = _runtime.sql_logs();
    println!("\n=== SQL LOGS ===");
    for (i, log) in sql_logs.iter().enumerate() {
        println!("{}: {:?}", i + 1, log);
    }
    println!("=== END SQL LOGS ===\n");

    Ok(())
}
