//! Customer-owned TeaQL playground for the school-management scenario.

use school_service_core::teaql_core::Entity;
use school_service_core::{AuditedSave, ServiceRuntime};

pub use school_service_core::{teaql_core, E, Q};

#[derive(Debug)]
pub struct ScenarioResult {
    pub extracted_school_name: String,
    pub extracted_platform_name: String,
    pub extracted_school_type_code: String,
    pub extracted_school_type_code_via_school: String,
    pub extracted_platform_id: u64,
    pub extracted_student_count: i64,
    pub primary_school_count: usize,
    pub primary_school_type_count: usize,
    pub sql_log_count: usize,
}

pub async fn run_school_scenario(
    ctx: &mut ServiceRuntime,
) -> Result<ScenarioResult, Box<dyn std::error::Error>> {
    ctx.enable_all_sql_log();

    let platforms = Q::platforms_minimal()
        .select_name()
        .limit(1)
        .comment("what: load the generated seed platform")
        .purpose("why: associate the demonstration school with its platform")
        .execute_for_list(ctx)
        .await?;
    let platform = platforms
        .first()
        .ok_or("generated platform seed is missing")?;
    let extracted_platform_name = E::platform(platform)
        .get_name()
        .eval()
        .ok_or("E expression could not extract the loaded platform name")?;

    let primary_school_types = Q::school_types_minimal()
        .select_name()
        .select_code()
        .select_platform_with(Q::platforms_minimal().select_name())
        .with_code_is("PRIMARY")
        .limit(5)
        .comment("what: load the Primary school type and its platform")
        .purpose("why: verify constant-object Q filtering and E extraction")
        .execute_for_list(ctx)
        .await?;
    let primary_school_type = primary_school_types
        .first()
        .ok_or("generated PRIMARY school type seed is missing")?;
    let extracted_school_type_code = E::school_type(primary_school_type)
        .get_code()
        .eval()
        .ok_or("E expression could not extract the school type code")?;

    let mut school = Q::schools()
        .purpose("why: create a Primary school for the Q and E API smoke test")
        .new_entity(ctx);
    school.update_name("Sunshine Primary School");
    school.update_address("456 Learning Lane");
    school.update_principal("Ms. Johnson");
    school.update_student_count(320);
    school.update_platform_id(platform.id());
    school.update_school_type_to_primary();
    school
        .clone()
        .audit_as("create Primary school for the TeaQL Q/E smoke test")
        .save(ctx)
        .await?;

    let primary_schools = Q::schools_minimal()
        .select_name()
        .select_address()
        .select_principal()
        .select_student_count()
        .select_platform_with(Q::platforms_minimal().select_name())
        .select_school_type_with(
            Q::school_types_minimal()
                .select_name()
                .select_code()
                .select_platform(),
        )
        .school_type_is_primary()
        .limit(20)
        .comment("what: load Primary schools and their display fields")
        .purpose("why: verify typed constant filtering and the saved school")
        .execute_for_list(ctx)
        .await?;

    let first_school = primary_schools
        .first()
        .ok_or("Primary school query returned no rows")?;
    let extracted_school_name = E::school(first_school)
        .get_name()
        .eval()
        .ok_or("E expression could not extract the loaded school name")?;
    let extracted_school_type_code_via_school = E::school(first_school)
        .get_school_type()
        .get_code()
        .eval()
        .ok_or("E expression could not traverse School -> School Type -> code")?;
    let extracted_platform_id = E::school(first_school)
        .get_platform_id()
        .eval()
        .ok_or("E expression could not extract the school platform ID")?;
    let extracted_student_count = E::school(first_school)
        .get_student_count()
        .eval()
        .ok_or("E expression could not extract the student count")?;

    Ok(ScenarioResult {
        extracted_school_name,
        extracted_platform_name,
        extracted_school_type_code,
        extracted_school_type_code_via_school,
        extracted_platform_id,
        extracted_student_count,
        primary_school_count: primary_schools.len(),
        primary_school_type_count: primary_school_types.len(),
        sql_log_count: ctx.sql_logs().len(),
    })
}

pub fn generated_domain_crate() -> &'static str {
    "school-service-core"
}
