# TeaQL Rust School Management Quick-Try Report

## Goal

Build and run a small Rust TeaQL school-management scenario on branch
`autonomous`. The semantic domain contains `Platform`, `School`, and the
constant object `School Type` with `Primary` and `Secondary`.

The DGX-hosted `NVIDIA-Nemotron-3-Super-120B-A12B-NVFP4` model was used through
the local MiMoCode client for autonomous modeling/review and customer-code
implementation. TeaQL generation, compilation, tests, and final runtime
verification ran locally.

## Directory Layout

- `models/model.xml`: reviewed semantic source of truth.
- `MODEL_REVIEW.md`: review gate and autonomous assumptions.
- `rust-lib-core/`: generated, read-only TeaQL domain/runtime crate.
- `rust-app-console/`: generated runnable shell plus customer-owned source and
  tests.
- `rust-app-console/src/lib.rs`: reusable Q/E demonstration scenario.
- `rust-app-console/src/main.rs`: executable entrypoint and SQL-log output.
- `rust-app-console/tests/q_e_scenario.rs`: SQLite integration test.

Generated runtime code and customer experiment code remain separate.

## Model Review

Status: `confirmed_with_assumptions`.

Evaluation:

- Errors: 0
- Warnings: 0
- Suggestions: 1
- Solids: 15

The non-blocking suggestion is to add `display_order="number()"` to
`school_type` for stable UI sorting.

Reviewed model:

- `Platform` is the single domain root and tenancy boundary.
- `School` references both `Platform` and `School Type`.
- `School Type` is a constant object with `PRIMARY` (1001) and `SECONDARY`
  (1002), and is associated with `Platform`.
- The playground assumes platform-managed tenancy and representative fields:
  school name, address, principal, and student count.

During the gate, the final model and the first review summary were found to have
different field names. Generation was stopped, the review was synchronized to
the actual model, and the current model was evaluated again before generation.

## Generated Runtime

`cargo-teaql` was force-refreshed and verified as exactly `2.0.8`.

The generated library exposes typed `Q`, `E`, entity/request types, constant
helpers, SQLite runtime registration, seed graph, and schema bootstrap. The app
console contains its own generated `AGENTS.md`, Cargo project, Tokio entrypoint,
runtime guide, and a path dependency on `../rust-lib-core/lib`.

The generator resolved `--output app-playground/...` relative to
`--cwd app-playground`, initially creating a double `app-playground` path. The
two complete generated directories were moved, without editing their contents,
to the documented locations above.

`ensure_schema()` is used here as a local playground convenience. Production
schema changes should be executed through an explicit migration/deployment
workflow.

## Customer Playground

The scenario:

1. Initializes the generated SQLite runtime and schema/seed graph.
2. Loads the generated seed platform through `Q::platforms_minimal()`.
3. Creates one Primary school through `Q::schools().new_entity(ctx)`.
4. Uses generated update methods and `.audit_as(...)` before `.save(...)`.
5. Queries the `PRIMARY` constant with `Q::school_types_minimal()`.
6. Queries Primary schools with the typed
   `.school_type_is_primary()` constant filter and loads Platform and School
   Type relations.
7. Uses E expressions for School name, Platform name, School Type code,
   Platform ID, student count, and a loaded
   `School -> School Type -> code` relation chain.
8. Captures TeaQL SQL logs.

Every executing query includes both `.comment(...)` and `.purpose(...)`.

```rust
let primary_schools = Q::schools_minimal()
    .select_name()
    .select_address()
    .select_principal()
    .select_student_count()
    .school_type_is_primary()
    .limit(20)
    .comment("what: load Primary schools and their display fields")
    .purpose("why: verify typed constant filtering and the saved school")
    .execute_for_list(ctx)
    .await?;

let name = E::school(primary_schools.first().unwrap())
    .get_name()
    .eval();

let type_code = E::school(primary_schools.first().unwrap())
    .get_school_type()
    .get_code()
    .eval();
```

## Q and E Runtime Result

Final clean-database run:

```text
Q/E scenario passed: 1 Primary school row(s), 1 Primary type row(s),
E school = "Sunshine Primary School",
platform = "Standard Education Platform",
type = "PRIMARY", platform_id = 1, students = 320,
9 SQL log entries
```

Observed SQL included:

```sql
INSERT INTO school_data
  (id, name, address, principal, student_count, create_time,
   update_time, version, platform, school_type)
VALUES
  (1, 'Sunshine Primary School', '456 Learning Lane',
   'Ms. Johnson', 320, ..., 1, 1, 1001);

SELECT id, version, name, address, principal, student_count
FROM school_data
WHERE ((version > 0) AND (school_type = 1001))
LIMIT 20;
```

The extended run executed three explicit Q requests. Relation loaders expanded
these into eight selects plus one insert. The Primary-school select returned
one row in 65 microseconds in this local run.

## Commands and Results

```text
cargo teaql --input app-playground/models/model.xml evaluate
PASS: 0 errors, 0 warnings, 1 suggestion

cargo teaql --input app-playground/models/model.xml rust-lib-core \
  --output app-playground/rust-lib-core --cwd app-playground
PASS

cargo teaql --input app-playground/models/model.xml rust-app-console \
  --output app-playground/rust-app-console --cwd app-playground
PASS

cargo teaql --input app-playground/models/model.xml \
  rust-assist-query/school
cargo teaql --input app-playground/models/model.xml \
  rust-assist-create/school
cargo teaql --input app-playground/models/model.xml \
  rust-assist-expression/school
cargo teaql --input app-playground/models/model.xml \
  rust-assist-query/platform
cargo teaql --input app-playground/models/model.xml \
  rust-assist-runtime-custom
cargo teaql --input app-playground/models/model.xml \
  rust-assist-debug/school
PASS

cargo fmt
PASS

CARGO_HTTP_PROXY= CARGO_HTTPS_PROXY= cargo check
PASS

CARGO_HTTP_PROXY= CARGO_HTTPS_PROXY= cargo test
PASS: 1 integration test

SCHOOL_SERVICE_CORE_DATABASE_URL=sqlite:///tmp/<fresh-db> \
  CARGO_HTTP_PROXY= CARGO_HTTPS_PROXY= cargo run
PASS
```

The proxy override was needed because the machine-wide Cargo proxy still
pointed at an unavailable local port. No global Git or Cargo configuration was
changed.

## Nemotron Agent Findings

The model successfully read the repository governance, invoked model-specific
TeaQL assists, produced the semantic model/review, and wrote a plausible first
customer-code implementation.

Its first Rust implementation did not pass compilation:

- It guessed five entity accessors as `get_*` instead of using `name()`,
  `address()`, and `student_count()`.
- It guessed `get_id()` rather than using the `Entity::id()` trait method.
- It omitted the `Entity` trait import required for `.audit_as()`.
- It formatted `SqlLogEntry` with `Display`, although it only supported debug
  formatting.

This produced eight compiler errors. After compiler-guided repair, the code
compiled. A second issue was discovered at runtime: passing `"320"` to the
numeric update path silently produced `0`; changing the input to `320` produced
the expected SQL value. This is an important pass@1 failure even though the
overall repair loop succeeded.

The generated runtime-custom assist did not expose a reusable concrete runtime
type for a shared library function. After assist proved incomplete, a minimal
read-only generated-source fallback established that `ServiceRuntime` aliases
`teaql_runtime::UserContext`; this fallback is recorded here as required.

## TeaQL Value Demonstrated

- Natural language became a semantic model before code.
- A review gate blocked generation until the model and review matched.
- Q/E/update names came from model-specific generated assist.
- Typed constant filtering replaced ad-hoc SQL.
- Query and mutation intent was explicit through purpose/comment/audit.
- Generated runtime and customer code stayed separate.
- SQLite SQL remained observable and assertable.
- The integration test can be rerun after every model change.

## Next Steps

1. Add `display_order` to `School Type` if UI ordering is required.
2. Add a uniqueness rule or lookup-before-create behavior for school identity.
3. Add a Secondary-school branch and compare Primary/Secondary query results.
4. In the model benchmark, require the coding agent to run `cargo check` before
   claiming completion and score pass@1 separately from repaired success.
